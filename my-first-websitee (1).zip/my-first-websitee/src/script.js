const button = document.getElementById("showPhotos");
const photos = document.getElementById("photos");

button.addEventListener("click", function() {
  photos.innerHTML = `
    <iframe src="https://assets.pinterest.com/ext/embed.html?id=8796161770480023"></iframe>
    <iframe src="https://assets.pinterest.com/ext/embed.html?id=863776403573872168"></iframe>
    <iframe src="https://assets.pinterest.com/ext/embed.html?id=608760074699963043"></iframe>
    <iframe src="https://assets.pinterest.com/ext/embed.html?id=614882155412907031"></iframe>
    <iframe src="https://assets.pinterest.com/ext/embed.html?id=888546201539717070"></iframe>
  `;
});